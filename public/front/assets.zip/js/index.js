const current_langs=document.querySelectorAll(".current_lang")
const other_langs=document.querySelector(".other_langs")

current_langs.forEach(item=>{
    item?.addEventListener("click",()=>{
        item.nextElementSibling.classList.toggle("active")
    })
})

var home_hero = new Swiper(".home-hero-slide", {
    loop: true,
    speed: 2500,
    slidesPerView: 1,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    autoplay:{
        delay:2500,
    }
});


const hamburger=document.querySelector(".hamburger")
const mobile_menu=document.querySelector(".mobile_menu")
const close_menu=document.querySelector(".close-menu")
hamburger.addEventListener("click",()=>{
    mobile_menu.style.left="0" 
})
close_menu.addEventListener("click",()=>{
    mobile_menu.style.left="-200%" 
})

const mobile_menu_link=document.querySelectorAll(".mobile_menu_link");
mobile_menu_link.forEach(item=>{
    item?.addEventListener("click",()=>{
        mobile_menu.style.left="-200%" 
    })
})

var home_news = new Swiper(".home-news-slide", {
    speed: 2500,
    slidesPerView: "auto",
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    spaceBetween:20,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    autoplay:{
        delay:2500,
    }
});

var news_detail_slide = new Swiper(".news-detail-slide", {
    speed: 2500,
    slidesPerView: "auto",
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    spaceBetween:20,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    autoplay:{
        delay:2500,
    }
});

var latest_news = new Swiper(".lastest_news", {
    speed: 2500,
    slidesPerView: "auto",
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    spaceBetween:20,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    autoplay:{
        delay:2500,
    }
});
var most_read_news_swiper= new Swiper(".most-read-news-swiper", {
    speed: 2500,
    slidesPerView: "auto",
    spaceBetween:20,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    autoplay:{
        delay:2500,
    }
});


const footer_section_title=document.querySelectorAll('.footer-section-title')
footer_section_title.forEach(item=>{
    item?.addEventListener('click',function(){
        let footer_section = item.parentElement;
        closeFooterLink(footer_section);
        if(footer_section.classList.contains("active")) footer_section.classList.remove('active');
        else footer_section.classList.add("active");
    })
})
function closeFooterLink(footerLinks){
    footer_section_title.forEach(item=>{
        let footer_section = item.parentElement;
        if(footerLinks != footer_section) footer_section.classList.remove("active");
    })  
}



const copiedBtn = document.querySelector('.simply_link');
const copiedTxt = document.querySelector('.copied_text');

copiedBtn?.addEventListener('click', function () {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(window.location.href).then(function () {
      copiedTxt.style.display = "block";
      setTimeout(() => copiedTxt.style.display = 'none', 800);
    });
  } else {
    // Fallback for older browsers
    const textArea = document.createElement("textarea");
    textArea.value = window.location.href;
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    document.execCommand('copy');
    copiedTxt.style.display = "block";
    setTimeout(() => copiedTxt.style.display = 'none', 800);
    document.body.removeChild(textArea);
  }
});


const faqItems = document.querySelectorAll('.faq-item');
const body = document.querySelector('body');
faqItems.forEach(item => {
    const button = item.querySelector('.accordion-title');
    button?.addEventListener('click', function (e) {
        if (item.classList.contains('active')) {
                item.classList.remove('active');
                button.querySelector('.bi').classList.replace('bi-dash', 'bi-plus');
            } else {
                faqItems.forEach(i => {
                    i.classList.remove('active');
                    i.querySelector('.bi').classList.replace('bi-dash', 'bi-plus');
                });
                item.classList.add('active');
                button.querySelector('.bi').classList.replace('bi-plus', 'bi-dash');
            }
        });
    });
body?.addEventListener('click', function (e) {
    if (!e.target.closest('.faq-item')) {
            faqItems.forEach(item => {
            item.classList.remove('active');
            item.querySelector('.bi').classList.replace('bi-dash', 'bi-plus');
        });
    }
});


const useful_info_btn=document.querySelector(".useful_info_btn")
useful_info_btn?.addEventListener("click",()=>{
    useful_info_btn.parentElement.classList.toggle("active_info_box")
})

document.querySelector('.mobile_submenu')?.addEventListener('click', function() {
    this.classList.toggle('active');
});

